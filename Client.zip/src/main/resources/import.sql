INSERT INTO tb_client(name, cpf, income, birth_date, children) VALUES
('JOSE WINDOWS 95 DA SILVA','000.000.101-01', 7320.50, '1995-08-24', 5);